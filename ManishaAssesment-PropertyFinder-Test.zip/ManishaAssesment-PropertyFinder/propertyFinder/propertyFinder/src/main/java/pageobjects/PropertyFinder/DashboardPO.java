package pageobjects.PropertyFinder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.base.BasePO;

import java.util.List;
import java.util.stream.Collectors;


public class DashboardPO extends BasePO {
    public DashboardPO(WebDriver driver) {
        super(driver);
    }


    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */

    @FindBy(xpath = "//div[contains(@class,'multi-selection-autocomplete')]/input[contains(@class,'multi-selection')]")
    private WebElement searchPropertyInput;

    @FindBy(xpath = "//span[contains(@class,'suggestion-text')]/strong")
    private WebElement firstSuggestionText;

    @FindBy(xpath = "//div[contains(@class,'dd__head')]//span[contains(text(),'Property type')]")
    private WebElement propertyTypeDropDown;

    @FindBy(xpath = "//button[contains(@class,'dropdown-list__item-content')][contains(text(),'Villa')]")
    private WebElement propertyDropDownOption;

    @FindBy(xpath = "//div[contains(@class,'dd__head')]//span[contains(text(),'Price')]")
    private WebElement priceDropdown;

    @FindBy(xpath = "//span[contains(text(),'Max')]/parent::div//following-sibling::div/div/input")
    private WebElement priceInput;


    @FindBy(xpath = "//button[contains(@class,'search-button')][2]")
    private WebElement searchButton;

    @FindBy(xpath = "//span[@aria-label='Search results count']")
    private WebElement searchResultCount;

    @FindBy(xpath = "//ul[@aria-label='Properties']/li")
    private By totalCardList;

    @FindBy(xpath = "//label[contains(@class,'checkbox-label')]/span")
    private WebElement showCommercialPropertyCheckBox;

    @FindBy(xpath = "//a[contains(@class,'link-module')]/span[text()='Offices']")
    private WebElement selectOfficesOption;

    @FindBy(xpath = "//span[text()='Apartments']/ancestor::div[1]/following-sibling::ul/li[1]//div/section[1]//a")
    private WebElement firstPropertyCard;

    @FindBy(xpath = "//span[text()='Capital Governorate']/ancestor::div[1]/following-sibling::div//ul/li[1]//div/section[2]//p[@data-testid='property-card-price']")
    private WebElement firstCardPrice;

    @FindBy(xpath = "//span[text()='Capital Governorate']/ancestor::div[1]/following-sibling::div//ul/li[1]//div/section[2]//h2")
    private WebElement firstCardDescription;

    @FindBy(xpath = "//span[text()='Capital Governorate']/ancestor::div[1]/following-sibling::div//ul/li[1]//div/section[2]//p[@data-testid='property-card-spec-area']")
    private WebElement firstCardSpaceArea;

    @FindBy(xpath = "//span[text()='Capital Governorate']/ancestor::div[1]/following-sibling::div//ul/li[1]//div/section[2]//div[@data-testid='property-card-location']")
    private WebElement firstCardLocation;


    // Property detail page


    @FindBy(xpath = "//span[text()='Available from:']/parent::div/following-sibling::div")
    private WebElement availableFromDate;


    public void EnterTextInSearchBox(String location) throws InterruptedException {
        selenium.click(searchPropertyInput);
        selenium.enterText(searchPropertyInput, location, false);
    }

    public void SelectProperty(String propertyType) throws InterruptedException {
        selenium.javascriptClickOn(propertyTypeDropDown);
        selenium.javascriptClickOn(propertyDropDownOption);
        //selenium.selectDropDownValueByText(propertyDropDownOptions, propertyType);
    }

    public void SelectMaximumPriceRange(String priceRange) throws InterruptedException {
        selenium.javascriptClickOn(priceDropdown);
        selenium.enterText(priceInput, priceRange, true);
    }

    public void ClickOnSearchButton() throws InterruptedException {
        selenium.click(searchButton);
    }

    public void ClickOnShowCommercialPropertyCheckBox() throws InterruptedException {
        selenium.click(showCommercialPropertyCheckBox);
    }

    public void SelectOfficesOptionFromCommercialList() throws InterruptedException {
        selenium.click(selectOfficesOption);
    }

    public void ClickOnFirstSuggestion() throws InterruptedException {
        selenium.click(firstSuggestionText);
    }

    public void ClickOnFirstPropertyCard() throws InterruptedException {
        selenium.hardWait(3);
        selenium.javascriptClickOn(firstPropertyCard);
    }

    public String GetSearchResultsCount() throws InterruptedException {
        String count = selenium.getText(searchResultCount);
        String[] abc = count.split(" ");
        return abc[0];
    }

    public int GetCardListCount() {
        int cnt = driver.findElements(By.xpath("//ul[@aria-label='Properties']/li")).size();
        return cnt;
    }

    // Property detail page

    public String GetAvailableFromPropertyValue() {
        return selenium.getText(availableFromDate);
    }

    public Boolean getTextOfPropertyPrice() {
        List<WebElement> priceList = driver.findElements(By.xpath("//ul[@aria-label='Properties']/li//p[@data-testid='property-card-price']"));
        List<String> price3 = priceList.stream()
                .map(WebElement::getText)
                .map(price -> price.replaceAll("[^0-9]", ""))
                .filter(price -> Integer.parseInt(price) <= 30000)
                .collect(Collectors.toList());

        return (priceList.size() == price3.size());
    }

    public Boolean isCardDescriptionPresent() {
        return selenium.isElementPresent(firstCardDescription);
    }


    public Boolean isCardLocationPresent() {
        return selenium.isElementPresent(firstCardLocation);
    }

    public Boolean isCardSpaceAreaPresent() {
        return selenium.isElementPresent(firstCardSpaceArea);
    }

    public Boolean isCardPricePresent() {
        return selenium.isElementPresent(firstCardPrice);
    }

}
