package utilities;

import com.google.common.io.Files;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class SeleniumHelpers extends WaitHelpers
{
	JavaHelpers helper;
	Actions actions;

	public SeleniumHelpers(WebDriver driver)
	{
		super(driver);
		helper = new JavaHelpers();
		actions = new Actions(driver);
	}

	// Take screenshot
	/**
	 * Take screenshot of the web page
	 * @param fileName screenshot file name
	 * @throws IOException
	 */
	public void takeScreenshot(String fileName) throws IOException
	{
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(scrFile,
				new File(Constants.SCREENSHOT_LOCATION + "\\" + fileName + helper.getTimeStamp("_yyyyMMdd_HHmmss") + ".png"));
	}


	//Elements
	/**
	 * Enter text to input field
	 * @param e WebElement object
	 * @param text input text
	 * @param clear set true if want to clear field else set false
	 */
	public void enterText(WebElement e, String text, boolean clear)
	{
		e = waitTillElementIsClickable(e);
		if(clear)
		{
			e.clear();
		}
		e.sendKeys(text);
	}

	/**
	 * Get Text from field
	 * @param e WebElement object
	 * @return text from field
	 */
	public String getText(WebElement e)
	{
		return waitTillElementIsVisible(e).getText().trim();
	}

	/**
	 * Click on Element (without waiting for it's clickable)
	 * @param e WebElement object
	 * @throws InterruptedException
	 */
	public void click(WebElement e) throws InterruptedException
	{
		e.click();
		waitForJavascriptToLoad();
	}

	/**
	 * method verify whether element is present on screen
	 *
	 * @param targetElement element to be present
	 * @return true if element is present else throws exception
	 */
	public Boolean isElementPresent(WebElement targetElement)
	{
		return waitInCaseElementVisible(targetElement,Constants.WEBDRIVER_WAIT_DURATION)!=null && waitInCaseElementVisible(targetElement,Constants.WEBDRIVER_WAIT_DURATION).isDisplayed();
	}


	//Navigation
	public void navigateToPage(String url)
	{
		driver.get(url);
	}

	public void javascriptClickOn(WebElement e) {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e);
	}
}

