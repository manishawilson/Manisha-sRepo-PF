package PropertyFinder;

import base.BaseTest;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pageobjects.PropertyFinder.DashboardPO;
import utilities.Constants;

public class DashboardTest extends BaseTest {

    @Test
    public void VerifySearchedResultCountDisplayedCorrectly() throws InterruptedException {

        DashboardPO dashboard = new DashboardPO(driver);

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(Constants.URL);

        Reporter.log("Step 2: Select Property type");
        dashboard.SelectProperty("Villa");

        Reporter.log("Step 3: Select maximum price range & click on search button");
        dashboard.SelectMaximumPriceRange("30000");
        dashboard.ClickOnSearchButton();

        Reporter.log("Step 4: Verify Property result are matched with actual cards list");
        String propertyCount = dashboard.GetSearchResultsCount();
        int cardListCount = dashboard.GetCardListCount();
        Assert.assertEquals(Integer.parseInt(propertyCount), cardListCount, "Card list count is not matched with property values");

        Reporter.log("Step 5: Get text of the all property price and verify all property price is less than 30000 ");
        Assert.assertTrue(dashboard.getTextOfPropertyPrice(), "Validation Failed: Some Property price is more than 30000");

    }

    @Test
    public void VerifyCommercialPropertyFilteredSuccessfully() throws InterruptedException {

        DashboardPO dashboard = new DashboardPO(driver);

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(Constants.URL);

        Reporter.log("Step 2:  Select the “show commercial properties only” checkbox and click on the search icon");
        dashboard.ClickOnShowCommercialPropertyCheckBox();
        dashboard.ClickOnSearchButton();

        Reporter.log("Step 3: From the commercial list returned, click on the “offices” category ");
        dashboard.SelectOfficesOptionFromCommercialList();

        Reporter.log("Step 5: Verify Property result are matched with actual cards list");
        String propertyCount = dashboard.GetSearchResultsCount();
        int cardListCount = dashboard.GetCardListCount();
        Assert.assertEquals(Integer.parseInt(propertyCount), cardListCount, "Card list count is not matched with property values");

        Assert.assertTrue(dashboard.isCardDescriptionPresent(), "Card Price is not present");
        Assert.assertTrue(dashboard.isCardSpaceAreaPresent(), "Card Size is not present");
        Assert.assertTrue(dashboard.isCardPricePresent(), "Card Price is not present");
        Assert.assertTrue(dashboard.isCardLocationPresent(), "Card Location is not present");
    }

    @Test
    public void VerifySearchPropertyByLocationWorkingSuccessfully() throws InterruptedException {

        DashboardPO dashboard = new DashboardPO(driver);

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(Constants.URL);

        Reporter.log("Step 2: search for “Bahrain Bay” location under the search box & Click on first suggestion");
        dashboard.EnterTextInSearchBox("Bahrain Bay");
        dashboard.ClickOnFirstSuggestion();

        Reporter.log("Step 3: Click on the search icon");
        dashboard.ClickOnSearchButton();

        Reporter.log("Step 4: Select the first property from the list and verify the Available from date should not be empty");
        dashboard.ClickOnFirstPropertyCard();
        Assert.assertNotNull(dashboard.GetAvailableFromPropertyValue(), "available From Date is empty!");
    }

}
